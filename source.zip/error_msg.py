AUTH_ERROR = {
    'wrong_pw': '비밀번호가 틀렸습니다.',
    'exist_email': '이미 존재하는 이메일입니다.',
    'no_user': '존재하지 않는 사용자입니다.',
    'pw_not_match': '비밀번호가 다릅니다.'
}

RENTAL_ERROR = {
    'no_stock': '재고가 없습니다.'
}